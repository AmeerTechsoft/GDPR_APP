"""
Management commands package for gdpr_platform.
""" 