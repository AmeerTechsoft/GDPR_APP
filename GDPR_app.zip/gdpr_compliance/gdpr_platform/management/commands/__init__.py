"""
Management commands for gdpr_platform.
""" 