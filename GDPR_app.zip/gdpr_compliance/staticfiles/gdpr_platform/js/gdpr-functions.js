// GDPR Platform JavaScript Functions

// Consent Management
function handleConsentUpdate(form) {
    const formData = new FormData(form);
    const submitButton = form.querySelector('button[type="submit"]');
    
    // Disable button during submission
    submitButton.disabled = true;
    submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Updating...';
    
    fetch(form.action, {
        method: 'POST',
        body: formData,
        headers: {
            'X-CSRFToken': formData.get('csrfmiddlewaretoken')
        }
    })
    .then(response => {
        if (!response.ok) throw new Error('Network response was not ok');
        return response.json();
    })
    .then(data => {
        showNotification('success', 'Consent preferences updated successfully');
        updateConsentHistory();
    })
    .catch(error => {
        showNotification('error', 'Failed to update consent preferences');
        console.error('Error:', error);
    })
    .finally(() => {
        submitButton.disabled = false;
        submitButton.innerHTML = 'Update Consent Preferences';
    });
}

// Data Request Management
function submitDataRequest(form) {
    const formData = new FormData(form);
    const submitButton = form.querySelector('button[type="submit"]');
    
    if (formData.get('request_type') === 'deletion') {
        if (!confirm('Are you sure you want to request deletion of your data? This action cannot be undone.')) {
            return false;
        }
    }
    
    submitButton.disabled = true;
    submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Submitting...';
    
    fetch(form.action, {
        method: 'POST',
        body: formData,
        headers: {
            'X-CSRFToken': formData.get('csrfmiddlewaretoken')
        }
    })
    .then(response => {
        if (!response.ok) throw new Error('Network response was not ok');
        return response.json();
    })
    .then(data => {
        showNotification('success', 'Data request submitted successfully');
        updateRequestsList();
    })
    .catch(error => {
        showNotification('error', 'Failed to submit data request');
        console.error('Error:', error);
    })
    .finally(() => {
        submitButton.disabled = false;
        submitButton.innerHTML = 'Submit Request';
        form.reset();
    });
}

// Breach Notification Management
function acknowledgeBreachNotification(notificationId) {
    const button = document.querySelector(`button[data-notification-id="${notificationId}"]`);
    const csrfToken = document.querySelector('[name=csrfmiddlewaretoken]').value;
    
    button.disabled = true;
    button.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>';
    
    fetch(`/gdpr/breaches/acknowledge/${notificationId}/`, {
        method: 'POST',
        headers: {
            'X-CSRFToken': csrfToken
        }
    })
    .then(response => {
        if (!response.ok) throw new Error('Network response was not ok');
        return response.json();
    })
    .then(data => {
        const notification = button.closest('.breach-notification');
        const acknowledgedText = document.createElement('p');
        acknowledgedText.className = 'text-xs text-success mb-0';
        acknowledgedText.innerHTML = `<i class="fas fa-check me-1"></i> Acknowledged on ${new Date().toLocaleString()}`;
        button.replaceWith(acknowledgedText);
    })
    .catch(error => {
        showNotification('error', 'Failed to acknowledge notification');
        console.error('Error:', error);
        button.disabled = false;
        button.innerHTML = 'Acknowledge Notification';
    });
}

// Utility Functions
function showNotification(type, message) {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.setAttribute('role', 'alert');
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    const alertsContainer = document.querySelector('.alerts-container') || document.body;
    alertsContainer.appendChild(alertDiv);
    
    setTimeout(() => {
        const bsAlert = new bootstrap.Alert(alertDiv);
        bsAlert.close();
    }, 5000);
}

function updateConsentHistory() {
    const historyContainer = document.querySelector('.consent-history');
    if (historyContainer) {
        fetch('/gdpr/consent/history/')
            .then(response => response.text())
            .then(html => {
                historyContainer.innerHTML = html;
            });
    }
}

function updateRequestsList() {
    const requestsContainer = document.querySelector('.data-requests-list');
    if (requestsContainer) {
        fetch('/gdpr/data-rights/requests/')
            .then(response => response.text())
            .then(html => {
                requestsContainer.innerHTML = html;
            });
    }
}

// Export Data
function downloadPersonalData(format = 'json') {
    const downloadButton = document.querySelector('.download-data-btn');
    downloadButton.disabled = true;
    downloadButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Preparing...';
    
    fetch(`/gdpr/data-rights/download/?format=${format}`)
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.blob();
        })
        .then(blob => {
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `personal_data.${format}`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
        })
        .catch(error => {
            showNotification('error', 'Failed to download personal data');
            console.error('Error:', error);
        })
        .finally(() => {
            downloadButton.disabled = false;
            downloadButton.innerHTML = 'Download Personal Data';
        });
}

// Initialize event listeners
document.addEventListener('DOMContentLoaded', function() {
    // Consent form submission
    const consentForm = document.querySelector('#consent-form');
    if (consentForm) {
        consentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleConsentUpdate(this);
        });
    }
    
    // Data request form submission
    const dataRequestForm = document.querySelector('#data-request-form');
    if (dataRequestForm) {
        dataRequestForm.addEventListener('submit', function(e) {
            e.preventDefault();
            submitDataRequest(this);
        });
    }
    
    // Breach notification acknowledgment
    const acknowledgeButtons = document.querySelectorAll('.acknowledge-breach-btn');
    acknowledgeButtons.forEach(button => {
        button.addEventListener('click', function() {
            acknowledgeBreachNotification(this.dataset.notificationId);
        });
    });
    
    // Data download buttons
    const downloadButtons = document.querySelectorAll('.download-data-btn');
    downloadButtons.forEach(button => {
        button.addEventListener('click', function() {
            downloadPersonalData(this.dataset.format || 'json');
        });
    });
});